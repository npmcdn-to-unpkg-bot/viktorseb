/// <reference path="globals/angular-route/index.d.ts" />
/// <reference path="globals/angular/index.d.ts" />
/// <reference path="globals/geojson/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
/// <reference path="globals/leaflet/index.d.ts" />
/// <reference path="globals/oclazyload/index.d.ts" />
