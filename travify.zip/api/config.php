<?php
    require_once('/classes/API.php');

    class PageCfg{
        //Config
        private $host = 'localhost';
        private $db = 'travify';
        private $username = 'root';
        private $password = '';
        //End of config

        public function getConnection(){
            $db = null;
            try{
                $db = new PDO("mysql:dbname=".$this->db.";host=".$this->host, $this->username, $this->password);
            } catch (PDOException $e){
                error_log("There was an error with database connection: ", $e->getMessage());
            }
            return $db;
        }
    }
?>