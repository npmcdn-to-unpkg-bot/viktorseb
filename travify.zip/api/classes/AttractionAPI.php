<?php
    require_once("API.php");

    class AttractionAPI extends API{
        public function getAllImages($folder){
            
        }
    }
?>