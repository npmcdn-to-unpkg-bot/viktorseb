<?php
    abstract class API{
        protected $pageCfg;
        protected $db;
        protected $user;
        public function __construct(){
            $this->pageCfg = new PageCfg();
            $this->db = $this->pageCfg->getConnection();
        }
        public abstract function run();
        
        public function requireAdmin(){
            requireUser();
            if ($this->user->rank < 3){
                exit;
            }
        }
        public function requireUser(){
            if ($this->user == 0){
                exit;
            }
        }
    }
?>