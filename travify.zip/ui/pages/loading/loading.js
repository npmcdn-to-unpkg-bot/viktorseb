class PageLoading {
    constructor($location, $route) {
        setTimeout(function () {
            $location.path('/newtrip-3');
            $route.reload();
        }, 2000);
    }
}
angular.module('travifyapp').component('pageLoading', {
    templateUrl: './ui/pages/loading/loading.html',
    controller: PageLoading
});
