angular.module('travifyapp').component('pageIndex', {
    templateUrl: './ui/pages/index/index.html'
});
