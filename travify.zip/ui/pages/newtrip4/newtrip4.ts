angular.module('travifyapp').component('pageNewtrip4', {
    templateUrl: './ui/pages/newtrip4/newtrip4.html'
});