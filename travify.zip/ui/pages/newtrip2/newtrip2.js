class NewTrip2 {
    constructor($scope) {
        'ngInject';
        $scope.savedClick = function (event) {
            angular.element(event.currentTarget).toggleClass('selected');
        };
    }
}
angular.module('travifyapp').component('pageNewtrip2', {
    templateUrl: './ui/pages/newtrip2/newtrip2.html',
    controller: NewTrip2
});
