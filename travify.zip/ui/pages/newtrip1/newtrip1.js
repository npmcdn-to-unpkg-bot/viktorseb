angular.module('travifyapp').component('pageNewtrip1', {
    templateUrl: './ui/pages/newtrip1/newtrip1.html'
});
