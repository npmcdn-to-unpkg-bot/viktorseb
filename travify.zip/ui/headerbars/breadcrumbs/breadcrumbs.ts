angular.module('travifyapp').component('breadcrumbs', {
    templateUrl: './ui/headerbars/breadcrumbs/breadcrumbs.html',
});