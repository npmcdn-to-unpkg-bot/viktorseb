angular.module('travifyapp').component('navigation', {
	templateUrl: './ui/components/navigation/navigation.html'
});